import sys
import numpy as np
import math


def createIndexDic(path):
    i=0
    dic = {}

    with open(path,"r")as readline:
        for eachLine in readline:
            eachLine = eachLine.strip("\n")
            dic[eachLine] = i
            i=i+1

    return dic

def createInverseIndexDic(path):
    i=0
    dic = {}

    with open(path,"r")as readline:
        for eachLine in readline:
            eachLine = eachLine.strip("\n")
            dic[i] = eachLine
            i=i+1

    return dic


def readTestWord(path):

    with open(path,"r")as readline:
        matrix=[]
        for eachLine in readline:
            lineList = []
            eachLine = eachLine.strip("\n")
            wordList = eachLine.split(" ")
            for word in wordList:
                lineList.append(word.split("_")[0])
            matrix.append(lineList)
    return matrix

def readHMM(path):
    with open(path,"r")as readline:
        matrix = []
        for eachLine in readline:
            eachLine = eachLine.strip("\n")
            line = eachLine.split(" ")
            for i in range (len(line)):
                line[i] = float(line[i])

            matrix.append(line)
    return matrix


def fillWPtable(transMatrix,emitMatrix,priorMatrix,observedSeq,W,P,wordDic,inverseTagDic):
    if len(observedSeq) == 1:
        index = wordDic[observedSeq[-1]]
        for i in range(len(priorMatrix)):
            W[i][0] = math.log(emitMatrix[i][index] * priorMatrix[i][0])

            P[i][0] = "NoPreviousState"

        return

    index = wordDic[observedSeq[-1]]

    curColumn = len(observedSeq)-1

    prevColumn = len(observedSeq)-2

    observedSeq.pop(-1)



    fillWPtable(transMatrix,emitMatrix,priorMatrix,observedSeq,W,P,wordDic,inverseTagDic)



    for i in range(len(priorMatrix)): #for each cell in time step t
        max = float("-inf")
        pos = 0
        for j in range(len(priorMatrix)): # for each cell in time step t-1
            value = math.log(emitMatrix[i][index]) + math.log(transMatrix[j][i]) + W[j][prevColumn]

            if(value>max):
                max = value
                pos = j

        W[i][curColumn] = max


        P[i][curColumn] = inverseTagDic[pos]


    return





def viterbi(transMatrix,emitMatrix,priorMatrix,testWordMatrix,wordDic,inverseTagDic,path,tagDic):

    with open (path,"w") as out:

        for i in range(len(testWordMatrix)):

            W = np.zeros((len(priorMatrix),len(testWordMatrix[i]))).tolist()
            P = np.zeros((len(priorMatrix),len(testWordMatrix[i]))).astype(np.str).tolist()

            observedSeq = testWordMatrix[i].copy()
            fillWPtable(transMatrix,emitMatrix,priorMatrix,observedSeq,W,P,wordDic,inverseTagDic)


            tagList = []
            max = float("-inf")
            lastColumnTag = ""


            for row in range(len(W)):
                value = W[row][len(testWordMatrix[i])-1]
                if value>max:
                    max = value
                    lastColumnTag = inverseTagDic[row]

            tagList.append(lastColumnTag)


            for col in range (len(testWordMatrix[i])-1,0,-1):

                currIndex = tagDic[lastColumnTag]

                lastColumnTag = P[currIndex][col]
                #print(lastColumnTag)

                tagList.append(lastColumnTag)


            tagList.reverse()

            for j in range(len(testWordMatrix[i])):
                word_tag = testWordMatrix[i][j].strip("\n").split("_")[0] + "_" + tagList[j]
                #print(word_tag)
                out.write(word_tag)
                if(j!=len(testWordMatrix[i])-1):
                    out.write(" ")
                else:
                    out.write("\n")


            #print(P)

            #print(tagList)

    print("finish")



def writeMetric(pathToTest, pathToPred, pathToMetric):
    test = []
    pred = []
    print("start")

    with open(pathToPred,"r") as predread:
        for eachLine in predread:
            eachLine = eachLine.strip("\n")
            for entry in eachLine.split(" "):
                pred.append(entry)


    #print(pred)

    with open(pathToTest,"r") as testread:
        for eachLine in testread:
            eachLine = eachLine.strip("\n")
            for entry in eachLine.split(" "):
                test.append(entry)

    #print(test)

    acc = 0.0
    errcount = 0

    if(len(pred)!= len(test)):
        print("Fatal error")

    for i in range(len(pred)):
        if(pred[i]!=test[i]):
            errcount = errcount+1
    acc = 1-errcount/len(pred)

    with open(pathToMetric,"w") as metricwrite:
        metricwrite.write("Accuracy: ")
        metricwrite.write(str(acc))


def main():

    wordDic = createIndexDic(sys.argv[2])
    tagDic = createIndexDic(sys.argv[3])
    inverseTagDic = createInverseIndexDic(sys.argv[3])


    transMatrix = readHMM(sys.argv[6])
    emitMatrix = readHMM(sys.argv[5])
    priorMatrix = readHMM(sys.argv[4])


    #print(transMatrix)
    #print(emitMatrix)
    #print(priorMatrix)

    testWordMatrix = readTestWord(sys.argv[1])
    #print(testWordMatrix)


    viterbi(transMatrix,emitMatrix,priorMatrix,testWordMatrix,wordDic,inverseTagDic,sys.argv[7],tagDic)

    writeMetric(sys.argv[1],sys.argv[7],sys.argv[8])



if __name__ == "__main__":
    main()